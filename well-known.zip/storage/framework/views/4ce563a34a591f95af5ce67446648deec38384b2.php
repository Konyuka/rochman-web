<?php $__env->startSection('title'); ?><?php echo $blog->title; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $blog->meta_description; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo $blog->meta_tags; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?><?php echo route('child.page',['products',$blog->url]); ?><?php $__env->stopSection(); ?>
<?php if($blog->thumbnail != ""): ?>
   <?php $__env->startSection('image'); ?><?php echo CMS::admin(); ?>/public/media/pages/<?php echo $blog->thumbnail; ?><?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('image'); ?><?php echo asset('assets/img/logo-lg.png'); ?> <?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->startSection('article'); ?>
   <meta property="article:publisher" content="https://www.facebook.com/RochmanPropertiesLtd" />
   <meta property="article:section" content="View all" />
   <meta property="article:published_time" content="<?php echo date('Y-m-d H:i:s', strtotime($blog->created_at)); ?>" />
   <meta property="article:modified_time" content="<?php echo date('Y-m-d H:i:s', strtotime($blog->updated_at)); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="pxp-content mb-100">
      <div class="pxp-blog-posts pxp-content-wrapper mt-100">
         <div class="container">
            <div class="row">
               <div class="col-sm-12 col-md-12 col-lg-12">
                  <div class="pxp-blog-post-category">
                     <span><?php echo date('Y-m-d H:i:s', strtotime($blog->created_at)); ?></span>
                  </div>
                  <h1 class="pxp-page-header"><?php echo $blog->title; ?></h1>
               </div>
            </div>
         </div>
         <?php if($blog->thumbnail): ?>
            <div class="pxp-blog-post-hero mt-4 mt-md-5">
               <div class="pxp-blog-post-hero-fig pxp-cover" style="background-image: url(<?php echo CMS::admin(); ?>media/posts/<?php echo $blog->thumbnail; ?>); background-position: 50% 50%;"></div>
            </div>
         <?php endif; ?>
         <div class="container <?php if($blog->thumbnail): ?> mt-100 <?php endif; ?>">
            <div class="row">
               <div class="col-sm-12 col-lg-1">
                  <div class="pxp-blog-post-share">
                     <div class="pxp-blog-post-share-label">Share</div>
                     <ul class="list-unstyled mt-3">
                        <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                        <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="#"><span class="fa fa-pinterest"></span></a></li>
                        <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                     </ul>
                     <div class="clearfix"></div>
                  </div>
               </div>
               <div class="col-sm-12 col-lg-10">
                  <div class="pxp-blog-post-block mt-4 mt-md-5 mt-lg-0">
                     <h2><?php echo $blog->title; ?></h2>
                     <div class="mt-3 mt-md-4">
                        <?php echo $blog->content; ?>

                     </div>
                  </div>
               </div>
            </div>
         </div>

         
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rochmanpropertie/public_html/resources/views/blog/details.blade.php ENDPATH**/ ?>
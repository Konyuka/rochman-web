<div class="pxp-footer pt-100 pb-100">
   <div class="container">
      <div class="row">
         <div class="col-sm-12 col-lg-4">
            <div class="pxp-footer-logo">
               <img src="<?php echo asset('assets/images/logo-lg.png'); ?>" alt="Rochman">
            </div>
            <div class="pxp-footer-social mt-2">
               <a href="#"><span class="fa fa-instagram"></span></a>
               <a href="#"><span class="fa fa-facebook-square"></span></a>
               <a href="#"><span class="fa fa-twitter"></span></a>
            </div>
         </div>
         <div class="col-sm-12 col-lg-8">
            <div class="row">
                  <div class="col-sm-12 col-md-4">
                     <h4 class="pxp-footer-header mt-4 mt-lg-0">Company</h4>
                     <ul class="list-unstyled pxp-footer-links mt-2">
                        <li><a href="<?php echo route('main.page','about-us'); ?>">About Us</a></li>
                        <li><a href="<?php echo route('main.page','blog'); ?>">Blog</a></li>
                        <li><a href="<?php echo route('main.page','contact-us'); ?>">Contact Us</a></li>
                     </ul>
                  </div>
                  <div class="col-sm-12 col-md-4">
                     <h4 class="pxp-footer-header mt-4 mt-lg-0">Actions</h4>
                     <ul class="list-unstyled pxp-footer-links mt-2">
                        <?php $__currentLoopData = CMS::product_categories(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li><a href="<?php echo route('properties.list',$category1->url); ?>"><?php echo $category1->name; ?></a> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                  </div>
                  <div class="col-sm-12 col-md-4">
                     <h4 class="pxp-footer-header mt-4 mt-lg-0">Address</h4>
                     <div class="pxp-footer-address mt-2">
                        1st Floor,Morningside Office Park, Ngong Road.<br>
                        P.O. Box 58622-00200 Nairobi, Kenya.<br>
                     </div>
                  </div>
            </div>
         </div>
      </div>

      <div class="pxp-footer-bottom mt-2">
         <div><a href="#">Terms & Conditions</a> and <a href="#">Privacy Policy</a></div>
         <div class="pxp-footer-copyright">&copy; Rochman Properties. All Rights Reserved. 2021</div>
      </div>
   </div>
</div>
<?php /**PATH /opt/lampp/htdocs/baroncabot/baroncabot.com/resources/views/partials/_footer.blade.php ENDPATH**/ ?>
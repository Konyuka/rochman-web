<?php $__env->startSection('title'); ?><?php echo $property->product_name; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $property->product_name; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo $property->product_name; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?><?php echo route('properties.details',$property->url); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('image'); ?><?php if(CMS::check_cover_image($property->id)==1): ?><?php echo CMS::admin(); ?>media/products/<?php echo CMS::cover_image($property->id)->file_name; ?><?php else: ?><?php echo asset('assets/images/placeholder.png'); ?><?php endif; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('article'); ?>
   <meta property="article:publisher" content="https://www.facebook.com/RochmanPropertiesLtd" />
   <meta property="article:section" content="View all" />
   <meta property="article:published_time" content="<?php echo date('Y-m-d H:i:s', strtotime($property->created_at)); ?>" />
   <meta property="article:modified_time" content="<?php echo date('Y-m-d H:i:s', strtotime($property->updated_at)); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('stylesheet'); ?>
   <link rel="stylesheet" href="<?php echo asset('assets/css/photoswipe.css'); ?>">
   <link rel="stylesheet" href="<?php echo asset('assets/css/default-skin/default-skin.css'); ?>">
   <link rel="stylesheet" href="<?php echo asset('assets/css/styled354.css'); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pxp-content">
   <div class="pxp-single-property-top pxp-content-wrapper mt-100">
      <div class="container">
         <div class="row">
            <div class="col-sm-12 col-md-5">
               <h2 class="pxp-sp-top-title"><?php echo $property->product_name; ?></h2>
               <p class="pxp-sp-top-address pxp-text-light"><?php echo $property->location; ?></p>
            </div>
            <div class="col-sm-12 col-md-7">
               <div class="pxp-sp-top-btns mt-2 mt-md-0">
                  <a href="#" class="pxp-sp-top-btn"><span class="fa fa-play"></span> Video</a>
                  <div class="dropdown">
                     <a class="pxp-sp-top-btn" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="fa fa-share-alt"></span> Share
                     </a>
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                        <a class="dropdown-item" href="#"><span class="fa fa-facebook"></span> Facebook</a>
                        <a class="dropdown-item" href="#"><span class="fa fa-twitter"></span> Twitter</a>
                     </div>
                  </div>
               </div>
               <div class="clearfix d-block d-xl-none"></div>
               <div class="pxp-sp-top-feat mt-3 mt-md-0">
                  <?php if($property->bedrooms): ?>
                     <div><?php echo $property->bedrooms; ?> <span>BD</span></div>
                  <?php endif; ?>
                  <?php if($property->bathroom): ?>
                     <div><?php echo $property->bathroom; ?> <span>BA</span></div>
                  <?php endif; ?>
                  <?php if($property->size): ?>
                     <div><?php echo $property->size; ?> <span>SF</span></div>
                  <?php endif; ?>
               </div>
               <div class="pxp-sp-top-price mt-3 mt-md-0">ksh <?php echo number_format($property->price); ?></div>
            </div>
         </div>
      </div>
   </div>

   <div class="pxp-single-property-gallery-container mt-4 mt-md-5">
      <div class="pxp-single-property-gallery" itemscope itemtype="http://schema.org/ImageGallery">
         <?php if(CMS::check_cover_image($property->id)==1): ?>
            <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject" class="pxp-sp-gallery-main-img">
               <a href="<?php echo CMS::admin(); ?>media/products/<?php echo CMS::cover_image($property->id)->file_name; ?>" itemprop="contentUrl" data-size="1920x1280" class="pxp-cover" style="background-image: url(<?php echo CMS::admin(); ?>media/products/<?php echo CMS::cover_image($property->id)->file_name; ?>);"></a>
               <figcaption itemprop="caption description">Image caption</figcaption>
            </figure>
         <?php else: ?>
            <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject" class="pxp-sp-gallery-main-img">
               <a href="<?php echo asset('assets/images/placeholder.png'); ?>" itemprop="contentUrl" data-size="1920x1280" class="pxp-cover" style="background-image: url(<?php echo asset('assets/images/placeholder.png'); ?>);"></a>
               <figcaption itemprop="caption description">Image caption</figcaption>
            </figure>
         <?php endif; ?>

         <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
               <a href="images/properties/prop-7-2-big.jpg" itemprop="contentUrl" data-size="1920x1459" class="pxp-cover" style="background-image: url(<?php echo CMS::admin(); ?>media/products/<?php echo $image->file_name; ?>);"></a>
               
               <figcaption itemprop="caption description">Image caption</figcaption>
            </figure>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         

      </div>
      <a href="#" class="pxp-sp-gallery-btn">View Photos</a>
      <div class="clearfix"></div>
   </div>

   <div class="container mt-100">
      <div class="row">
         <div class="col-lg-8 ">
            <div class="pxp-single-property-section">
               <h3>Key Details</h3>
               <div class="row mt-3 mt-md-4">
                  <?php if($property->type): ?>
                     <div class="col-sm-6">
                        <div class="pxp-sp-key-details-item">
                           <div class="pxp-sp-kd-item-label text-uppercase">Property Type</div>
                           <div class="pxp-sp-kd-item-value"><?php echo $property->type; ?></div>
                        </div>
                     </div>
                  <?php endif; ?>
                  <?php if($property->year): ?>
                     <div class="col-sm-6">
                        <div class="pxp-sp-key-details-item">
                           <div class="pxp-sp-kd-item-label text-uppercase">Year Built</div>
                           <div class="pxp-sp-kd-item-value"><?php echo $property->year; ?></div>
                        </div>
                     </div>
                  <?php endif; ?>
                  <?php if($property->stories): ?>
                  <div class="col-sm-6">
                     <div class="pxp-sp-key-details-item">
                        <div class="pxp-sp-kd-item-label text-uppercase">Stories</div>
                        <div class="pxp-sp-kd-item-value"><?php echo $property->stories; ?></div>
                     </div>
                  </div>
                  <?php endif; ?>
                  
                  <?php if($property->garadge): ?>
                     <div class="col-sm-6">
                        <div class="pxp-sp-key-details-item">
                           <div class="pxp-sp-kd-item-label text-uppercase">Parking Spaces</div>
                           <div class="pxp-sp-kd-item-value"><?php echo $property->garadge; ?></div>
                        </div>
                     </div>
                  <?php endif; ?>
               </div>
            </div>

            <div class="pxp-single-property-section mt-4 mt-md-5">
               <h3>Details</h3>
               <div class="mt-3 mt-md-4">
                  <?php echo $property->description; ?>

               </div>
            </div>

            <div class="pxp-single-property-section mt-4 mt-md-5">
               <h3>Amenities</h3>
               <div class="row mt-3 mt-md-4">
                  <?php if(CMS::check_string($property->amenities,'Internet')=='true'): ?>
                     <div class="col-sm-6 col-lg-4">
                        <div class="pxp-sp-amenities-item"><span class="fa fa-wifi"></span> Internet</div>
                     </div>
                  <?php endif; ?>
                  <?php if(CMS::check_string($property->amenities,'Garage')=='true'): ?>
                     <div class="col-sm-6 col-lg-4">
                        <div class="pxp-sp-amenities-item"><span class="fa fa-car"></span> Garage</div>
                     </div>
                  <?php endif; ?>
                  <?php if(CMS::check_string($property->amenities,'Air Conditioning')=='true'): ?>
                     <div class="col-sm-6 col-lg-4">
                        <div class="pxp-sp-amenities-item"><span class="fa fa-sun-o"></span> Air Conditioning</div>
                     </div>
                  <?php endif; ?>
                  <?php if(CMS::check_string($property->amenities,'Dishwasher')=='true'): ?>
                     <div class="col-sm-6 col-lg-4">
                        <div class="pxp-sp-amenities-item"><span class="fa fa-bullseye"></span> Dishwasher</div>
                     </div>
                  <?php endif; ?>
                  <?php if(CMS::check_string($property->amenities,'Disposal')=='true'): ?>
                     <div class="col-sm-6 col-lg-4">
                        <div class="pxp-sp-amenities-item"><span class="fa fa-recycle"></span> Disposal</div>
                     </div>
                  <?php endif; ?>
                  <?php if(CMS::check_string($property->amenities,'Balcony')=='true'): ?>
                     <div class="col-sm-6 col-lg-4">
                        <div class="pxp-sp-amenities-item"><span class="fa fa-clone"></span> Balcony</div>
                     </div>
                  <?php endif; ?>
                  <?php if(CMS::check_string($property->amenities,'Gym')=='true'): ?>
                     <div class="col-sm-6 col-lg-4">
                        <div class="pxp-sp-amenities-item"><span class="fa fa-futbol-o"></span> Gym</div>
                     </div>
                  <?php endif; ?>
                  <?php if(CMS::check_string($property->amenities,'Playroom')=='true'): ?>
                     <div class="col-sm-6 col-lg-4">
                        <div class="pxp-sp-amenities-item"><span class="fa fa-smile-o"></span> Playroom</div>
                     </div>
                  <?php endif; ?>
                  <?php if(CMS::check_string($property->amenities,'Bar')=='true'): ?>
                     <div class="col-sm-6 col-lg-4">
                        <div class="pxp-sp-amenities-item"><span class="fa fa-glass"></span> Bar</div>
                     </div>
                  <?php endif; ?>
               </div>
            </div>

            <div class="pxp-single-property-section mt-4 mt-md-5">
               <h3>Explore the Area</h3>
               <?php echo $property->map; ?>

            </div>

            <div class="pxp-single-property-section mt-md-5 mt-5">
               <h3>Payment Calculator</h3>
               <div class="pxp-calculator-view mt-3 mt-md-4">
                  <div class="row">
                     <div class="col-sm-12 col-lg-4 align-self-center">
                        <div class="pxp-calculator-chart-container">
                           <canvas id="pxp-calculator-chart"></canvas>
                           <div class="pxp-calculator-chart-result">
                              <div class="pxp-calculator-chart-result-sum">ksh 11,277</div>
                              <div class="pxp-calculator-chart-result-label">per month</div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-12 col-lg-8 align-self-center mt-3 mt-lg-0">
                        <div class="pxp-calculator-data">
                           <div class="row justify-content-between">
                              <div class="col-8">
                                    <div class="pxp-calculator-data-label"><span class="fa fa-minus"></span>Principal and Interest</div>
                              </div>
                              <div class="col-4 text-right">
                                    <div class="pxp-calculator-data-sum" id="pxp-calculator-data-pi"></div>
                              </div>
                           </div>
                        </div>
                        <div class="pxp-calculator-data">
                           <div class="row justify-content-between">
                              <div class="col-8">
                                    <div class="pxp-calculator-data-label"><span class="fa fa-minus"></span>Property Taxes</div>
                              </div>
                              <div class="col-4 text-right">
                                    <div class="pxp-calculator-data-sum" id="pxp-calculator-data-pt"></div>
                              </div>
                           </div>
                        </div>
                        <div class="pxp-calculator-data">
                           <div class="row justify-content-between">
                              <div class="col-8">
                                    <div class="pxp-calculator-data-label"><span class="fa fa-minus"></span>HOA Dues</div>
                              </div>
                              <div class="col-4 text-right">
                                 <div class="pxp-calculator-data-sum" id="pxp-calculator-data-hd"></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="pxp-calculator-form mt-3 mt-md-4">
                  <input type="hidden" id="pxp-calculator-form-property-taxes" value="ksh 1,068">
                  <input type="hidden" id="pxp-calculator-form-hoa-dues" value="ksh 2,036">
                  <div class="row">
                     <div class="col-sm-12 col-md-6">
                        <div class="form-group">
                           <label for="pxp-calculator-form-term">Term</label>
                           <select class="custom-select" id="pxp-calculator-form-term">
                              <option value="30">30 Years Fixed</option>
                              <option value="20">20 Years Fixed</option>
                              <option value="15">15 Years Fixed</option>
                              <option value="10">10 Years Fixed</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-sm-12 col-md-6">
                           <div class="form-group">
                              <label for="pxp-calculator-form-interest">Interest</label>
                              <input type="text" class="form-control pxp-form-control-transform" id="pxp-calculator-form-interest" data-type="percent" value="4.45%">
                           </div>
                     </div>
                     <div class="col-sm-12 col-md-6">
                           <div class="form-group">
                              <label for="pxp-calculator-form-price">Home Price</label>
                              <input type="text" class="form-control pxp-form-control-transform" id="pxp-calculator-form-price" data-type="currency" value="ksh 5,198,000">
                           </div>
                     </div>
                     <div class="col-sm-12 col-md-6">
                           <div class="row">
                              <div class="col-7 col-sm-7 col-md-8">
                                 <div class="form-group">
                                       <label for="pxp-calculator-form-down-price">Down Payment</label>
                                       <input type="text" class="form-control pxp-form-control-transform" id="pxp-calculator-form-down-price" data-type="currency" value="ksh 519,800">
                                 </div>
                              </div>
                              <div class="col-5 col-sm-5 col-md-4">
                                 <div class="form-group">
                                       <label for="pxp-calculator-form-down-percentage">&nbsp;</label>
                                       <input type="text" class="form-control pxp-form-control-transform" id="pxp-calculator-form-down-percentage" data-type="percent" value="10%">
                                 </div>
                              </div>
                           </div>
                     </div>
                  </div>
               </div>
            </div>

            <div class="pxp-single-property-section mt-4 mt-md-5 mb-5">
               <h3>Schools around</h3>
               <?php echo $property->schools; ?>

            </div>
         </div>
         <div class="col-lg-4">
            <div class="card">
               <div class="card-body bg-grey">
                  <h3 class="widget-subtitle">Book a Viewing</h3>
                  <p>For more information and free viewing, submit your contact details below.</p>
                  <form class="contact-box rt-contact-form" method="POST" action="<?php echo route('properties.view.inquiry'); ?>">
                     <input type="hidden" value="<?php echo $property->id; ?>" name="property_id" required>
                     <input type="hidden" value="<?php echo $property->product_name; ?> Viewing inquiry" name="subject" required>
                     <?php echo csrf_field(); ?>
                     <div class="row">
                        <div class="form-group col-lg-12">
                           <label for="">Your Names <span class="text-danger">*</span></label>
                           <input type="text" class="form-control" name="names" placeholder="Names" required/>
                        </div>

                        <div class="form-group col-lg-12">
                           <label for="">Your Phone number<span class="text-danger">*</span></label>
                           <input type="number" class="form-control" name="phone_number" placeholder="Phone number" required/>
                        </div>

                        <div class="form-group col-lg-12">
                           <label for="">Your Email </label>
                           <input type="email" class="form-control" name="email" placeholder="Email address"/>
                        </div>

                        <div class="form-group col-lg-6">
                           <label for="">Visit Date <span class="text-danger">*</span></label>
                           <input type="date" class="form-control" name="view_date" required/>
                        </div>

                        <div class="form-group col-lg-6">
                           <label for="">Visit Time <span class="text-danger">*</span></label>
                           <input type="time" class="form-control" name="view_time" required/>
                        </div>

                        <div class="form-group col-lg-12">
                           <label for="">Message </label>
                           <textarea  name="message" class="form-control" cols="30" rows="4" placeholder="start typing ......"></textarea>
                        </div>
                        <div class="form-group col-lg-12">
                           <div class="advanced-button">
                              <button type="submit" class="btn btn-success">
                                 Send Message
                              </button>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
   <script src="<?php echo asset('assets/js/photoswipe.min.js'); ?>"></script>
   <script src="<?php echo asset('assets/js/photoswipe-ui-default.min.js'); ?>"></script>
   <script src="<?php echo asset('assets/js/jquery.sticky.js'); ?>"></script>
   <script src="<?php echo asset('assets/js/gallery.js'); ?>"></script>
   <script src="<?php echo asset('assets/js/infobox.js'); ?>"></script>
   <script src="<?php echo asset('assets/js/single-map.js'); ?>"></script>
   <script src="<?php echo asset('assets/js/Chart.min.js'); ?>"></script>
   <script src="<?php echo asset('assets/js/main.js?asdasd12'); ?>"></script>

   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/rochman/rochman-properties.co.ke/resources/views/property/details.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?><?php echo $page->title; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $page->meta_description; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo $page->meta_tags; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?><?php echo route('child.page',['products',$page->url]); ?><?php $__env->stopSection(); ?>
<?php if($page->thumbnail != ""): ?>
   <?php $__env->startSection('image'); ?><?php echo CMS::admin(); ?>/public/media/pages/<?php echo $page->thumbnail; ?><?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('image'); ?><?php echo asset('assets/images/logo-lg.png'); ?> <?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->startSection('article'); ?>
   <meta property="article:publisher" content="https://www.facebook.com/RochmanPropertiesLtd" />
   <meta property="article:section" content="View all" />
   <meta property="article:published_time" content="<?php echo date('Y-m-d H:i:s', strtotime($page->created_at)); ?>" />
   <meta property="article:modified_time" content="<?php echo date('Y-m-d H:i:s', strtotime($page->updated_at)); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('stylesheet'); ?>
   <style>
      .item-img {
         opacity: 1;
         /* background-color: rgb(236 250 247); */
         padding: 30px 30px 30px 30px;
      }

      .border-radius{
         border-radius: 24px
      }

   </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="pxp-content">
      <div class="pxp-contact pxp-content-wrapper mt-100 mb-100">
         <div class="container">
            <div class="row">
               <div class="col-sm-12 col-md-7">
                     <h1 class="pxp-page-header">Contact Us</h1>
                     <p class="pxp-text-light">Say hello. Tell us how we can guide you.</p>
               </div>
            </div>
         </div>

         <div class="pxp-contact-hero mt-4 mt-md-5">
            <div class="pxp-contact-hero-fig pxp-cover" style="background-image: url(<?php echo asset('assets/images/contact-bg.jpg'); ?>); background-position: 50% 80%;"></div>

            <div class="pxp-contact-hero-offices-container">
               <div class="container">
                  <div class="pxp-contact-hero-offices">
                     <h2 class="pxp-section-h2">Contacts</h2>
                     <div class="row">
                        <div class="col-sm-12 col-md-4">
                           <div class="pxp-contact-hero-offices-info mt-2 mt-md-3">
                              <p class="pxp-is-address">1st Floor,Morningside Office Park, Ngong Road.</p>
                              <p class="pxp-is-address"> P.O. Box 58622-00200 Nairobi, Kenya.</p>
                           </div>
                        </div>
                        <div class="col-sm-12 col-md-4">
                           <div class="pxp-contact-hero-offices-info mt-2 mt-md-3">
                              <p class="pxp-is-address"><a href="tel:+254 707 111 777"> +254 707 111 777</a><br><a href="mailto:sales@rochman-properties.co.ke">sales@rochman-properties.co.ke</a></p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <div class="container mt-200">
            <div class="row">
               <div class="col-sm-12 col-lg-6">
                  <h2 class="pxp-section-h2">Send Us A Message</h2>
                  <div class="pxp-contact-form mt-3 mt-md-4">
                     <form action="">
                        <div class="row">
                           <div class="col-sm-12 col-md-6">
                                 <div class="form-group">
                                    <input type="text" class="form-control" id="pxp-contact-form-name" placeholder="Name">
                                 </div>
                           </div>
                           <div class="col-sm-12 col-md-6">
                                 <div class="form-group">
                                    <input type="text" class="form-control" id="pxp-contact-form-email" placeholder="Email">
                                 </div>
                           </div>
                           <div class="col-sm-12 col-md-6">
                              <div class="form-group">
                                 <input type="text" class="form-control" placeholder="Subject" id="pxp-contact-form-phone">
                              </div>
                           </div>
                           <div class="col-sm-12 col-md-6">
                              <div class="form-group">
                                 <input type="text" class="form-control" placeholder="Phone (optional)" id="pxp-contact-form-phone">
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <textarea class="form-control" id="pxp-contact-form-message" rows="6" placeholder="Message"></textarea>
                        </div>
                     <a href="#" class="pxp-contact-form-btn">Send Message</a>
                     </form>
                  </div>
               </div>
               <div class="col-sm-12 col-lg-6">
                  <div class="row mt-4 mt-md-5 mt-lg-0">
                     <div class="col-6">
                        <h2 class="pxp-section-h2">Our Locations</h2>
                     </div>
                  </div>
                  <div class="mt-3">
                     <iframe src="https://maps.google.com/maps?q=Morning+Side+Office+Park,+Ngong+Rd,+Nairobi&amp;t=&amp;z=16&amp;ie=UTF8&amp;iwloc=&amp;output=embed" width="100%" height="330" frameborder="0" style="border:0" allowfullscreen></iframe>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baroncabot/baroncabot.com/resources/views/pages/contact.blade.php ENDPATH**/ ?>
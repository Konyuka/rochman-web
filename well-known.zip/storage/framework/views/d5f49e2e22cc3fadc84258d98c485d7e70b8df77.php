<?php $__env->startSection('title'); ?><?php echo $page->title; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $page->meta_description; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo $page->meta_tags; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?><?php echo route('child.page',['products',$page->url]); ?><?php $__env->stopSection(); ?>
<?php if($page->thumbnail != ""): ?>
   <?php $__env->startSection('image'); ?><?php echo CMS::admin(); ?>/public/media/pages/<?php echo $page->thumbnail; ?><?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('image'); ?><?php echo asset('assets/img/logo-lg.png'); ?> <?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->startSection('article'); ?>
   <meta property="article:publisher" content="https://www.facebook.com/RochmanPropertiesLtd" />
   <meta property="article:section" content="View all" />
   <meta property="article:published_time" content="<?php echo date('Y-m-d H:i:s', strtotime($page->created_at)); ?>" />
   <meta property="article:modified_time" content="<?php echo date('Y-m-d H:i:s', strtotime($page->updated_at)); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="pxp-content">
      <div class="pxp-blog-posts pxp-content-wrapper mt-100">
         <div class="container">
            <h1 class="pxp-page-header">Latest Articles</h1>
            <div class="row mt-100">
               <div class="col-sm-12 col-lg-9">
                  <div class="row">
                     <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-12 col-md-6">
                           <a href="<?php echo route('blog.details',$blog->url); ?>" class="pxp-posts-1-item">
                              <div class="pxp-posts-1-item-fig-container">
                                 <?php if($blog->thumbnail): ?>
                                    <div class="pxp-posts-1-item-fig pxp-cover" style="background-image: url(<?php echo CMS::admin(); ?>media/posts/<?php echo $blog->thumbnail; ?>);"></div>
                                 <?php else: ?>
                                    <div class="pxp-posts-1-item-fig pxp-cover" style="background-image: url(<?php echo asset('assets/images/placeholder.png'); ?>);"></div>
                                 <?php endif; ?>
                              </div>
                              <div class="pxp-posts-1-item-details">
                                 
                                 <div class="pxp-posts-1-item-details-title"><?php echo $blog->title; ?></div>
                                 <div class="pxp-posts-1-item-details-date mt-2"><?php echo date('F jS, Y', strtotime($blog->created_at)); ?></div>
                                 <div class="pxp-posts-1-item-cta text-uppercase">Read Article</div>
                              </div>
                           </a>
                        </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  
               </div>
               <div class="col-sm-12 col-lg-3 mt-4 mt-md-5 mt-lg-0">
                  <div class="pxp-blog-posts-side-section">
                     <h3>Search Articles</h3>
                     <div class="mt-3 mt-md-4">
                        <div class="form-group">
                           <input type="text" class="form-control pxp-is-address" placeholder="Search">
                           <span class="fa fa-search"></span>
                        </div>
                     </div>
                  </div>

                  <div class="pxp-blog-posts-side-section mt-4 mt-md-5">
                     <h3>Categories</h3>
                     <ul class="pxp-blog-posts-side-v-list list-unstyled mt-3 mt-md-4">
                        <li><a href="#">Fashion (3)</a></li>
                        <li><a href="#">Lifestyle (2)</a></li>
                        <li><a href="#">Personal (2)</a></li>
                        <li><a href="#">Stories (2)</a></li>
                        <li><a href="#">Travel (4)</a></li>
                     </ul>
                  </div>

                  <div class="pxp-blog-posts-side-section mt-4 mt-md-5">
                     <h3>Tags</h3>
                     <div class="pxp-blog-posts-side-tags mt-3 mt-md-4">
                           <a href="#">Premium (10)</a>
                           <a href="#">Interior (12)</a>
                           <a href="#">Stories (6)</a>
                           <a href="#">Fashion (2)</a>
                           <a href="#">Architecture (8)</a>
                           <a href="#">Lifestyle (5)</a>
                           <a href="#">Travel (10)</a>
                           <a href="#">Personal (11)</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>

   <div class="pxp-full pxp-cover pt-100 pb-100 mt-100" style="background-image: url(<?php echo asset('assets/images/newsletter-1-fig.jpg'); ?>);">
      <div class="container">
         <h2 class="pxp-section-h2">Stay Up to Date</h2>
         <p class="pxp-text-light">Subscribe to our newsletter to receive our weekly feed</p>
         <div class="row mt-4 mt-md-5">
            <div class="col-xs-12 col-sm-6">
               <form action="http://pixelprime.co/themes/Rochman Properties./light/blog.html" class="pxp-newsletter-1-form">
                  <input type="text" class="form-control" placeholder="Enter your email...">
                  <a href="#" class="pxp-primary-cta text-uppercase pxp-animate mt-3 mt-md-4">Subscribe</a>
               </form>
            </div>
         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rochmanpropertie/public_html/resources/views/blog/classic.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?><?php echo $page->title; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $page->meta_description; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo $page->meta_tags; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?><?php echo route('child.page',['products',$page->url]); ?><?php $__env->stopSection(); ?>
<?php if($page->thumbnail != ""): ?>
   <?php $__env->startSection('image'); ?><?php echo CMS::admin(); ?>/public/media/pages/<?php echo $page->thumbnail; ?><?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('image'); ?><?php echo asset('assets/images/logo-lg.png'); ?> <?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->startSection('article'); ?>
   <meta property="article:publisher" content="https://www.facebook.com/RochmanPropertiesLtd" />
   <meta property="article:section" content="View all" />
   <meta property="article:published_time" content="<?php echo date('Y-m-d H:i:s', strtotime($page->created_at)); ?>" />
   <meta property="article:modified_time" content="<?php echo date('Y-m-d H:i:s', strtotime($page->updated_at)); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('stylesheet'); ?>
   <style>
      .item-img {
         opacity: 1;
         /* background-color: rgb(236 250 247); */
         padding: 30px 30px 30px 30px;
      }

      .border-radius{
         border-radius: 24px
      }

   </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="pxp-contact pxp-content-wrapper mt-100">
      <div class="container">
         <div class="row">
            <div class="col-sm-12 col-md-12 mb-2">
                  <h1 class="pxp-page-header text-center">About Us</h1>
            </div>
         </div>
      </div>
      <div class="pxp-cta-3 mt-100 mb-5">
         <div class="container">
            <div class="row align-items-center">
               <div class="col-lg-6">
                  <div class="pxp-cta-3-image pxp-cover rounded-lg" style="background-image: url(<?php echo asset('assets/images/about.jpg'); ?>);"></div>
               </div>
               <div class="col-lg-1"></div>
               <div class="col-lg-5">
                  <h2 class="pxp-section-h2 mt-3 mt-md-5 mt-lg-0">Who we are</h2>
                  <p class="pxp-text-light mt-3 mt-lg-4">Rochman Properties has a heritage of 15 years in the real estate industry, driven by a vision to provide quality property solutions in Kenya that offers optimum returns of investment. With its wealth of experience, Rochman Properties Limited is continuously dedicated to providing environmentally sustainable, strategically located and economically viable properties within Kenya.</p>

               </div>
            </div>
         </div>
      </div>

      

      
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rochmanpropertie/public_html/resources/views/pages/about.blade.php ENDPATH**/ ?>
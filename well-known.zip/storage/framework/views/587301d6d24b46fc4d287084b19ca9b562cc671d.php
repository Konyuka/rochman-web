<?php if(request()->route()->getName() == 'home.page'): ?>
   <div class="pxp-header fixed-top pxp-animate">
<?php else: ?>
   <div class="pxp-header pxp-full fixed-top">
<?php endif; ?>
   <div class="container">
      <div class="row align-items-center">
         <div class="col-5 col-md-3">
            <a href="<?php echo url('/'); ?>" class="pxp-logo text-decoration-none">
               <img src="<?php echo asset('assets/images/logo.png'); ?>" alt="Rochman">
            </a>
         </div>
         <div class="col-2 col-md-8 text-center">
            <ul class="pxp-nav list-inline">

               <li class="list-inline-item"><a href="<?php echo url('/'); ?>">Home</a></li>
               <li class="list-inline-item">
                  <a href="#">Properties</a>
                  <ul class="pxp-nav-sub rounded-lg">
                     <?php $__currentLoopData = CMS::product_categories(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo route('properties.list',$category1->url); ?>"><?php echo $category1->name; ?></a> </li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
               </li>
               <li class="list-inline-item">
                  <a href="#">Projects</a>
                  <ul class="pxp-nav-sub rounded-lg">
                     <?php $__currentLoopData = CMS::product_categories(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo route('properties.list',$category1->url); ?>"><?php echo $category1->name; ?></a> </li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
               </li>
               <?php if(CMS::check_menu(1) == 1): ?>
                  <?php $__currentLoopData = CMS::menu_main_pages(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuPages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li class="list-inline-item">
                        <?php if($menuPages->custom_url != ""): ?>
                           <a href="<?php echo $menuPages->custom_url; ?>" class=""><?php echo $menuPages->title; ?></a>
                        <?php else: ?>
                           <a href="<?php echo route('main.page',$menuPages->url); ?>" class=""><?php echo $menuPages->title; ?></a>
                        <?php endif; ?>
                        <?php if(CMS::check_menu_page_children(1,$menuPages->pageID) > 0): ?>
                           <ul class="">
                              <?php $__currentLoopData = CMS::menu_page_children(1,$menuPages->pageID); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li>
                                    <?php if($child->custom_url != ""): ?>
                                       <a href="<?php echo $child->custom_url; ?>"><?php echo $child->title; ?></a>
                                    <?php else: ?>
                                       <a href="<?php echo route('child.page',[$menuPages->url,$child->url]); ?>"><?php echo $child->title; ?></a>
                                    <?php endif; ?>
                                 </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </ul>
                        <?php endif; ?>
                     </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>
               
               
            </ul>
         </div>
         <div class="col-5 col-md-1 text-right">
            <a href="javascript:void(0);" class="pxp-header-nav-trigger"><span class="fa fa-bars"></span></a>
            <a href="tel:2540707111777" class="pxp-header-user"><span class="fa fa-phone"></span></a>
         </div>
      </div>
   </div>
</div>
<?php /**PATH /opt/lampp/htdocs/rochman/rochman-properties.co.ke/resources/views/partials/_header.blade.php ENDPATH**/ ?>
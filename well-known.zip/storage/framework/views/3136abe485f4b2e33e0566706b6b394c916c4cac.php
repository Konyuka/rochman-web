<?php $__env->startSection('title'); ?><?php echo $page->title; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $page->meta_description; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo $page->meta_tags; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?><?php echo route('child.page',['products',$page->url]); ?><?php $__env->stopSection(); ?>
<?php if($page->thumbnail != ""): ?>
   <?php $__env->startSection('image'); ?><?php echo CMS::admin(); ?>/public/media/pages/<?php echo $page->thumbnail; ?><?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('image'); ?><?php echo asset('assets/images/logo-lg.png'); ?> <?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
   <div class="pxp-content">
      <div class="pxp-contact pxp-content-wrapper mt-100">
         <div class="container">
            <div class="row">
               <div class="col-sm-12 col-md-12 mb-100">
                     <h1 class="pxp-page-header text-center"><?php echo $page->title; ?></h1>
               </div>
            </div>
         </div>
         <div class="container mb-100">
            <?php echo $page->content; ?>

         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rochmanpropertie/public_html/resources/views/pages/general.blade.php ENDPATH**/ ?>
<?php return array (
  'properties' => 'App\\Http\\Livewire\\Properties',
);
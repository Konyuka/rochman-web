<?php

namespace App\Model\General;
use Illuminate\Database\Eloquent\Model;

class inquiry extends Model
{
   Protected $table = 'emails';
}

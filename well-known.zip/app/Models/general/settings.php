<?php

namespace App\Models\general;
use Illuminate\Database\Eloquent\Model;

class settings extends Model
{
   Protected $table = 'settings';
}

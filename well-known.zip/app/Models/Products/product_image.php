<?php

namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;

class product_image extends Model
{
   Protected $table = 'product_media';
}

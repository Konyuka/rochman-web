<?php

namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;

class categories extends Model
{
   Protected $table = 'product_category';
}

<?php

namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;

class product_category extends Model
{
   Protected $table = 'product_category_product_information';
}

<?php

namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;

class products extends Model
{
   Protected $table = 'product_information';
}

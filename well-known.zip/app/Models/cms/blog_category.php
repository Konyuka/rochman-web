<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class blog_category extends Model
{
    Protected $table = 'blog_category';
}

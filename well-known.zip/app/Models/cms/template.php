<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class template extends Model
{
   Protected $table = 'page_template';
}

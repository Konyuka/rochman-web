<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class subscribers extends Model
{
    Protected $table = 'subscribers';
}

<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class slider extends Model
{
    Protected $table = 'sliders';
}

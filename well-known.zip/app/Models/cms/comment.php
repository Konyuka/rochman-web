<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class comment extends Model
{
    Protected $table = 'comment';
}

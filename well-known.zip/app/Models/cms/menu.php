<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class menu extends Model
{
   Protected $table = 'menu';
}

<?php

namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class attachment extends Model
{
    Protected $table = 'attachment';
}

<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class gallery extends Model
{
   Protected $table = 'gallery';
}

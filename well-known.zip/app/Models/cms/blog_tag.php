<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class blog_tag extends Model
{
    Protected $table = 'blog_tag';
}

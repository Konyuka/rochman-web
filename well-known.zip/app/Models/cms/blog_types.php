<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class blog_types extends Model
{
    Protected $table = 'blog_types';
}

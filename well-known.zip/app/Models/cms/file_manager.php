<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class file_manager extends Model
{
   Protected $table = 'file_manager';
}

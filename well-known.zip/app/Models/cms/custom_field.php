<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class custom_field extends Model
{
    Protected $table = 'custome_field';
}

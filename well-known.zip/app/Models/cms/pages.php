<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class pages extends Model
{
    Protected $table = 'pages';
}

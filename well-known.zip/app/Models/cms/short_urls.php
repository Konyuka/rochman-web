<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class short_urls extends Model
{
    Protected $table = 'short_urls';
}

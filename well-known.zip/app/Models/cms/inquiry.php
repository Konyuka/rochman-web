<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class inquiry extends Model
{
   Protected $table = 'inquiry';
}

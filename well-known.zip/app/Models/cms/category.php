<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class category extends Model
{
    Protected $table = 'category_blogs';

}

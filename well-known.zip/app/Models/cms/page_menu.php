<?php
namespace App\Models\cms;

use Illuminate\Database\Eloquent\Model;

class page_menu extends Model
{
   Protected $table = 'page_menu';
}
